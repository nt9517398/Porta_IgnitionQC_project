# CHANGELOG v1.5.4 — Ground truth from real documents; superseded views removed

**Delta from v1.5.3:** two open items resolved from real source documents (not guessed), a real config-data defect found and fixed, dead code removed. **Confidence shift:** DB platform now confirmed fact, not inference; Lathe Outfeed tolerances now sourced, though several remain flagged pending QC confirmation.

---

## DB platform: resolved

The Gateway Database Connection Report is decisive: PostgreSQL, host `rmfplydbs01:5432`, JDBC driver `PostgreSQL`, SQL Translator `POSTGRES`. My PostgreSQL-first schema choice was correct.

**But it also caught something I'd been getting wrong the entire build.** The real Gateway **datasource name is `site_quality_control`** — not `PortaPlywood_QC_DB`, which every named query in this project referenced. All **18 named queries** were pointing at a datasource that doesn't exist on the Gateway; every one would have failed at runtime. Fixed across all 18.

## Lathe Outfeed tolerances: resolved, with several items flagged rather than smoothed over

Reference **05-20-39**, issued 27 Feb 2026, read via a formula-and-cached-value pass so nothing came from eyeballing a screenshot. Migration 004 rewritten with real values, replacing every `[ASSUMED]` placeholder. New content the source revealed that v1.5.3 didn't have at all:

- **Clipping Width** (RHS/MID/LHS) — grade-dependent: HI, LOW SAP (thickness-independent), and SAP (thickness-dependent, 2.4mm vs 3.0mm). Maps cleanly onto the existing schema's NULL-as-wildcard specification matching — no schema change needed.
- **Diagonal Diff** — two raw corner readings with no individual limit; only their *difference* is judged, against a fixed 15mm max. Modeled as two raw characteristics plus a calculated one (`qc.measurement.is_calculated` already existed for this).
- **Scribe Length** — a spec exists, but flagged: the sheet lists nominal as "2400mm" while min/target/max are 2535/2545/2570 — 135–170mm *above* the stated nominal. That's too large for ordinary tolerance. I have a guess (oversize pre-trim mark vs. finished length) but it's a guess, not something the sheet states — flagged for QC to confirm rather than asserted as fact.
- **Thickness position order** — corrected to match the sheet exactly: RHS, MID, LHS (v1.5.3 had LHS, MID, RHS). Matching the printed form's own order matters more than internal tidiness.

**All specifications remain DRAFT.** A source document with a reference number is not the same as this system's own approval event — the schema requires `approved_by`/`approved_at` for ACTIVE, and I have neither. Fabricating an approver would violate the no-fabrication rule. The resolver still blocks submission until QC actions the activation steps at the bottom of `004_seed_lathe_outfeed.sql`.

**A real gap, not swept under the rug:** the sheet has three ATTRIBUTE-type fields — Moisture Grade (HI/LOW SAP/SAP), Tight (G/F/P), Scribe (G/F/P) — that `shared/NumericMeasurement` cannot render; the Flex Repeater's `props.path` is hardcoded to one component for every instance. Seeding those characteristics now would put visibly broken fields in front of an operator, so they're deliberately withheld until an `AttributeMeasurement` component and type-routing exist. Worth flagging: Moisture Grade isn't cosmetic — it's a real dependency the Clipping Width resolver needs (`gradeCode`), and nothing currently supplies it.

**The sheet's own non-conformance procedure requires HOLD** ("place all offending packs on HOLD") — that stays deliberately dormant per your Level 1 scope decision, not lost.

## Superseded views: removed, with everything that pointed at them

`lathe`, `dryer_infeed`, `dryer_outfeed`, `finished_panel` deleted, along with `components/measurement_field` — once the four were gone it had zero remaining references anywhere in the project, so it's dead code, not a future dependency.

This wasn't just deleting four folders. `page-config/config.json` routed all four paths to these views **and** set `defaultPage: /lathe` — deleting the views without fixing this would have left the app with no working landing page. `nav_shell` had four menu links pointing at the same dead routes. Both fixed: `/lathe-outfeed` is now the default page and the only entry-form nav link; `/spc`, `/correlation`, `/alarms` are untouched since they weren't part of what you flagged as confusing.

## Verification

```
JSON failures       : 0
script failures     : 0 (of 11)   [wrap-then-parse oracle]
dangling view refs  : none
dbConnection wrong  : 0 (of 18)   [was 18/18 wrong]
seed-script code consistency : confirmed (every referenced characteristic_code is defined)
```

Remaining views: `alarms/alarm_ack_popup`, `alarms/alarm_status`, `charts/cross_stage_correlation`, `charts/lathe_spc`, `shared/NumericMeasurement`, `shell/nav_shell`, `tech/lathe_outfeed`.

---

## Reduced-motion: what actually needs a decision from you

Two separate questions, and I don't want to conflate them.

**1. Product question — does this even apply to your deployment?** `prefers-reduced-motion` is a browser/OS-level accessibility setting suppressing animation for users sensitive to motion. It's designed around *personal* devices where an individual sets their own accessibility preference. If Lathe Outfeed and future stations run on **shared, fixed shop-floor tablets** (whoever's on shift that hour), this setting reflects whoever last touched that device's OS settings, not a specific operator's need — its practical value on a shared kiosk is genuinely different from a personal laptop or phone. If any station is or will be a personal/BYOD device, or if this is a blanket accessibility requirement regardless of device-sharing, that changes the answer.

**2. Mechanical question — even if wanted, I haven't verified how to build it.** The 27 Style Classes in this project are fully verified against real committed Ignition exports — I have real `{"base": {"style"|"animation"}}` examples to build from. A `@media (prefers-reduced-motion: reduce)` query is a different mechanism — it would need the Advanced Project Stylesheet (confirmed real and project-scoped via IA's own 8.1.22 release notes) — but I have **no real example of that specific resource's file structure**, unlike Style Classes. I'd be reconstructing it from documentation prose alone, which is exactly the pattern that produced the fabricated chart schema and the wrong `classes` array format earlier in this build. I don't want to repeat that on an accessibility feature.

**What I need from you:** the product decision (below), and if you want it built — ideally a small real example of an Advanced Stylesheet resource if you can grab one from Designer (even an empty one added via right-click → New Resource → Stylesheet would show me the real `resource.json` shape), or permission to spend a research pass hunting for verified real examples before writing anything.
