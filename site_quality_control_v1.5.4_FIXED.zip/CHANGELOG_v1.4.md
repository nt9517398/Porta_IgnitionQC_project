# CHANGELOG v1.4 — Porta brand theme rollout, chart schema fixes, comments migration

## Fixed — Critical (both were runtime crashes in the imported v1.3)

- **`measurement_field` failed to commit** (Designer error dialog: `ExecutionException: Unexpected return type; expected string, got null`). Root cause: the expression transform assumed `{value}` was always a number, but on the initial render before the indirect tag resolves, `value` is null — passing null to `toString(round(...))` returns null, which the label's `text` prop can't accept. Fixed by adding `fallbackValue: 0` to the tag binding and wrapping the transform in `if(isNull({value}), "--", ...)`. Also verified this matches Ignition's own documented `isNull()` idiom.

- **`lathe_spc` chart threw the same "expected string, got null" error at runtime**, and the Designer property editor was flagging every series entry with `series[].color is not defined in the schema` / `series[].field is not defined in the schema` / `data is missing but it is required`. Root cause: the chart's `props` were built to a fabricated shape that never actually existed — top-level `series[].color`, `series[].field`, `series[].dashed`, and dataset-level `xField` — that came out of a prior audit session where the chart component was never opened in the Designer, only its underlying SQL was fixed. Rebuilt both `lathe_spc` and `cross_stage_correlation` to the real Time Series Chart schema per Inductive Automation's official 8.1 component reference: one series per query binding, `series[].data` set via binding (required, not optional), styling via `plots[].trends[].columns[].color` — no series-level color, no `dashed`, no `xField`. UCL/LCL and target lines still render as separate `trends` entries, just in the correct place. Both charts should now render without schema errors.

## Added — full Porta brand theme rollout across all 4 data-entry stations

**Root cause of the previous look:** the `porta-mes-theme.css` file was well-built (verified `#D01040` crimson matching the logo, WCAG-AA-verified contrast ratios, proper Modern-Table-reference deployment mechanism) — but `DEPLOYMENT.md` explicitly claimed *"I've already wired `style.classes` on every button/header/table in this build"* and this turned out not to be true. Every station view had `"classes": []` — empty. The dark-green appearance in the imported project wasn't the theme; it was Ignition's default styling because no theme classes were ever applied. This pass actually connects the theme to the components, using the layout from the Sander Falldown reference the user provided.

**New layout pattern, uniform across `lathe`, `dryer_infeed`, `dryer_outfeed`, `finished_panel`:**

- **Info bar** (52px, `psc-porta-info-bar` — white background, 2px crimson bottom border): actual Porta logo image on the left (using `com.inductiveautomation.perspective/images/porta_logo_converted.png`, already in the project), station title, then compact `Shift` / `Line` label-value pairs on the right. Replaces the previous dark-green header block.
- **Body**: two-column, entry on the left (440px), history on the right (grow).
- **Entry column**: dense measurement rows inside a card-style container (1px light-neutral border, 8px border-radius, `overflow: hidden` to clip the alternating rows against the rounded corners). Comments field bound to `view.custom.commentsText`. Primary crimson Enter button (`psc-porta-button-primary`). Status label and last-entry-by label.
- **History column**: `Recent` header, `ia.display.table` bound to the corresponding `qc/*/history` named query, `psc-porta-table` styling, 15-second polling, `t_stamp` column formatted to `HH:mm` (not raw UTC strings).

**Shared `measurement_field` component** restructured from a vertical 3-part card into a horizontal 40px zebra row: `label | value (right-aligned, bold) | - | +`. New boolean `alt` view param controls the background color via an expression binding (`#F7F6F2` when true, `#FFFFFF` when false), letting the parent alternate rows without dynamic class-array binding (which prior orchestra rounds already flagged as risky). All existing bindings and Python scripts preserved verbatim — only layout changed. Step buttons narrowed from 44px to 36px to fit the dense row while still comfortably above touch minimums.

**Theme file extended** with three new class families (`psc-porta-info-bar`, `psc-porta-entry-row`, `psc-porta-pill`) alongside the existing verified classes. The pill palette reuses the existing `--qc-status-*` variables (not new colors) so a "in spec" pill on a data-entry row and an alarm in the journal always mean the same thing color-wise.

## Added — comments field (schema migration + full wiring)

- **`002_add_comments_column.sql`**: `ALTER TABLE ... ADD COLUMN IF NOT EXISTS comments TEXT` on all 3 quality tables. Nullable, no backfill, safe against a live database already running v1.3. The `001_...schema.sql` DDL was also updated to include the column for fresh installs.
- **All 3 `insert_record` named queries** updated: `comments` added to the INSERT column list, `:comments` parameter added to VALUES, `comments` parameter (VarChar) added to `resource.json`.
- **All 4 data-entry views** wired: `view.custom.commentsText` bound to a text-field, passed through the `extraParams` dict on submit, cleared to `""` on successful submit (only on success — a failed submit preserves what the operator typed).

## GLM design-review integration (external second look on the completed pattern)

Called GLM-5.2 to attack the replicated pattern once all 4 views were built. Applied its concrete, evidence-based fixes:

- **Border width** widened from `0.5px` to `1px` on the measurement-list card wrapper — GLM correctly pointed out that sub-pixel borders round to 0 on non-Retina shop-floor tablet displays.
- **`t_stamp` column render** set to `date` with `HH:mm` format on every history table — GLM correctly pointed out the default renderer produces raw UTC-string mangling.
- **Async clear** flagged by GLM as a potential race — confirmed already correct by construction, since `QC.submit_measurement` uses `system.db.runNamedQuery` which is synchronous, and the clear only fires inside the `if success:` branch.

Declined (with reasons, not silently):

- **Bind to `style.classes` conditionally instead of `style.backgroundColor` directly.** GLM's own attack in a prior conversation round flagged dynamic class-array binding as risky and unresolved against real reference repos. The style-property expression binding is the more conservative choice here, at the cost of a bit of runtime overhead that isn't measurable on this row count.
- **Replace fixed 15-second polling with a tag-change refresh mechanism.** Real point — 15s lag between operators is genuinely non-ideal — but it needs a new tag + gateway-event architecture that would touch 8+ files across UDT definitions, tag configs, and gateway scripts. Right thing to do next, wrong scope for this pass.

## Confidence, honestly

Same as v1.3: this is verified against real Ignition 8.1 documentation and real, working reference repos; not verified against a live Designer import in this environment. The two runtime crashes you screenshotted (`measurement_field` commit + `lathe_spc` render) were traced to specific, understood causes and fixed at the source, so they should be gone — but any of the layout choices could still surface something a live import would catch. If the new pattern imports and renders anywhere close to the mockup, the remaining 6 views (SPC/correlation chart hosts, alarm views, nav_shell) can get the same theme rollout as v1.5.
