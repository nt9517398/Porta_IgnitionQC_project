-- =============================================================================
-- Porta Myrtleford — QC Process Control Framework schema
-- Migration 003 | v1.5.3 | Aligned to "Ignition QC Process Control System,
--                          Complete project framework, Draft 0.2" (16 Jul 2026)
-- =============================================================================
--
-- WHY THIS EXISTS
-- Migrations 001/002 built one wide table per station (qc.lathe_quality,
-- qc.dryer_quality, qc.finished_panel_quality). Every new form needed a new
-- table plus a new hardcoded page. The framework's own risk register names
-- this as risk #1: "One-off pages proliferate -> High maintenance and
-- inconsistent rules -> Mitigation: Configuration-driven renderer and shared
-- components." The plant has ~15 forms across 10 areas, so that design does
-- not reach production.
--
-- This migration adds the configuration-driven model: forms, sections and
-- characteristics are DATA, not DDL. Commissioning form #2 becomes an INSERT,
-- not a schema change.
--
-- COEXISTENCE, NOT REPLACEMENT
-- 001/002 tables are NOT dropped. They hold live data and the Gateway has
-- working Transaction Groups against them. This schema stands alongside until
-- a data migration is separately agreed and tested. Nothing here touches them.
--
-- ============================ PLATFORM CONFLICT ==============================
-- [UNRESOLVED — NEEDS NGUYEN'S DECISION]
-- Framework section 16.3 says the first release reads/writes "the SQL Server
-- database". Framework section 19.1 simultaneously lists "Confirm target
-- Ignition version and database platform" as a still-open next artefact. The
-- deployed reality is PostgreSQL 14 with live data and a working
-- PortaPlywood_QC_DB connection.
--
-- This DDL targets PostgreSQL 14, matching what is actually deployed rather
-- than the unconfirmed statement. To keep a SQL Server migration cheap, this
-- schema deliberately avoids PostgreSQL-only constructs:
--   - VARCHAR + CHECK instead of ENUM types (SQL Server has no CREATE TYPE
--     AS ENUM; PG's ALTER TYPE ADD VALUE also cannot run inside a transaction)
--   - No JSONB in any column on the transactional path
--   - No INTERVAL columns (durations stored as INTEGER seconds)
-- Remaining SQL Server deltas, should the platform change:
--   BIGSERIAL          -> BIGINT IDENTITY(1,1)
--   TIMESTAMPTZ        -> DATETIMEOFFSET(7)
--   TEXT               -> NVARCHAR(MAX)
--   now()              -> SYSDATETIMEOFFSET()
--   CURRENT_DATE       -> CAST(GETDATE() AS DATE)
--   LIMIT n            -> OFFSET 0 ROWS FETCH NEXT n ROWS ONLY
--   Partial indexes (WHERE ...) are supported as filtered indexes — same syntax
-- =============================================================================

-- Reuses the existing qc schema and qc.lines table from migration 001.

-- -----------------------------------------------------------------------------
-- CONFIGURATION LAYER — effective-dated, soft-retired, never hard-deleted
-- (framework rule: "do not delete historical definitions referenced by records")
-- -----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS qc.form_definition (
    form_id         BIGSERIAL PRIMARY KEY,
    form_code       VARCHAR(50)  NOT NULL UNIQUE,
    title           VARCHAR(200) NOT NULL,
    doc_reference   VARCHAR(100),
    business_owner  VARCHAR(100) NOT NULL,
    process_stage   VARCHAR(50)  NOT NULL
        CHECK (process_stage IN ('VENEER_PREPARATION','VENEER_ASSEMBLY',
                                 'LAYUP_AND_PRESS','FINISHING','TOOLING')),
    form_family     VARCHAR(50)  NOT NULL
        CHECK (form_family IN ('DIMENSIONAL','REPEATED_LOAD','TIME_DURATION',
                               'TOOLING_SETUP','ATTRIBUTE','SCHEDULED_COMPLIANCE')),
    retired_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by      VARCHAR(64) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_form_def_stage ON qc.form_definition (process_stage)
    WHERE retired_at IS NULL;

CREATE TABLE IF NOT EXISTS qc.form_revision (
    revision_id       BIGSERIAL PRIMARY KEY,
    form_id           BIGINT NOT NULL REFERENCES qc.form_definition(form_id),
    revision_label    VARCHAR(20) NOT NULL,
    lifecycle_state   VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
        CHECK (lifecycle_state IN ('DRAFT','ACTIVE','SUPERSEDED')),
    effective_from    DATE NOT NULL,
    effective_to      DATE,
    approved_by       VARCHAR(64),
    approved_at       TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by        VARCHAR(64) NOT NULL,
    CONSTRAINT uq_form_revision UNIQUE (form_id, revision_label),
    CONSTRAINT chk_rev_dates CHECK (effective_to IS NULL OR effective_from <= effective_to),
    -- an ACTIVE revision must have been approved (framework: DRAFT->ACTIVE->SUPERSEDED
    -- with approval recorded)
    CONSTRAINT chk_rev_active_approved
        CHECK (lifecycle_state <> 'ACTIVE' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL))
);
-- At most one open-ended ACTIVE revision per form.
CREATE UNIQUE INDEX IF NOT EXISTS uq_form_revision_one_active
    ON qc.form_revision (form_id)
    WHERE lifecycle_state = 'ACTIVE' AND effective_to IS NULL;

CREATE TABLE IF NOT EXISTS qc.section_definition (
    section_id     BIGSERIAL PRIMARY KEY,
    revision_id    BIGINT NOT NULL REFERENCES qc.form_revision(revision_id),
    section_code   VARCHAR(50)  NOT NULL,
    title          VARCHAR(200) NOT NULL,
    display_order  INTEGER NOT NULL,
    CONSTRAINT uq_section UNIQUE (revision_id, section_code)
);
CREATE INDEX IF NOT EXISTS idx_section_revision ON qc.section_definition (revision_id, display_order);

CREATE TABLE IF NOT EXISTS qc.characteristic_definition (
    characteristic_id  BIGSERIAL PRIMARY KEY,
    section_id         BIGINT NOT NULL REFERENCES qc.section_definition(section_id),
    characteristic_code VARCHAR(50) NOT NULL,
    label              VARCHAR(200) NOT NULL,
    data_type          VARCHAR(16) NOT NULL
        CHECK (data_type IN ('NUMERIC','ATTRIBUTE','TIME','TEXT','BOOLEAN')),
    unit               VARCHAR(30),
    precision_dp       INTEGER CHECK (precision_dp IS NULL OR precision_dp BETWEEN 0 AND 6),
    -- Framework 4.1: "Use physical positions such as RHS/MID/LHS instead of
    -- ambiguous numbering where possible." Position is a first-class attribute.
    position_code      VARCHAR(20),
    display_order      INTEGER NOT NULL,
    is_required        BOOLEAN NOT NULL DEFAULT TRUE,
    -- Attribute characteristics only: pipe-delimited allowed choices.
    -- Deliberately NOT JSONB — keeps the SQL Server path open.
    allowed_values     VARCHAR(500),
    failure_message    VARCHAR(300),
    CONSTRAINT uq_characteristic UNIQUE (section_id, characteristic_code),
    CONSTRAINT chk_numeric_has_unit
        CHECK (data_type <> 'NUMERIC' OR unit IS NOT NULL),
    CONSTRAINT chk_attribute_has_choices
        CHECK (data_type <> 'ATTRIBUTE' OR allowed_values IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_char_section ON qc.characteristic_definition (section_id, display_order);

-- Specification: product/grade/variant/station dependent limits.
-- NULL in a matching column = wildcard ("applies to any"). Specificity ranking
-- in the resolver decides which of several matches wins; ties are a blocking
-- configuration error, never silently resolved.
CREATE TABLE IF NOT EXISTS qc.specification (
    specification_id   BIGSERIAL PRIMARY KEY,
    characteristic_id  BIGINT NOT NULL REFERENCES qc.characteristic_definition(characteristic_id),
    product_code       VARCHAR(64),
    grade_code         VARCHAR(32),
    nominal_thickness  NUMERIC(6,2),
    variant            VARCHAR(50),
    station_id         VARCHAR(32),
    min_value          NUMERIC(12,4),
    target_value       NUMERIC(12,4),
    max_value          NUMERIC(12,4),
    -- Warning band (framework status model: WARNING = "near limit"). Inset from
    -- min/max by this much. NULL = no warning band, straight PASS/FAIL.
    warn_inset         NUMERIC(12,4),
    unit               VARCHAR(30),
    lifecycle_state    VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
        CHECK (lifecycle_state IN ('DRAFT','ACTIVE','SUPERSEDED')),
    effective_from     DATE NOT NULL,
    effective_to       DATE,
    approved_by        VARCHAR(64),
    approved_at        TIMESTAMPTZ,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by         VARCHAR(64) NOT NULL,
    CONSTRAINT chk_spec_dates CHECK (effective_to IS NULL OR effective_from <= effective_to),
    CONSTRAINT chk_spec_limits CHECK (min_value IS NULL OR max_value IS NULL OR min_value <= max_value),
    CONSTRAINT chk_spec_target_in_range
        CHECK (target_value IS NULL
               OR ((min_value IS NULL OR target_value >= min_value)
               AND (max_value IS NULL OR target_value <= max_value))),
    CONSTRAINT chk_spec_active_approved
        CHECK (lifecycle_state <> 'ACTIVE' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_spec_resolve
    ON qc.specification (characteristic_id, product_code, grade_code)
    WHERE lifecycle_state = 'ACTIVE';

CREATE TABLE IF NOT EXISTS qc.schedule_rule (
    schedule_id        BIGSERIAL PRIMARY KEY,
    revision_id        BIGINT NOT NULL REFERENCES qc.form_revision(revision_id),
    station_id         VARCHAR(32),
    schedule_type      VARCHAR(20) NOT NULL
        CHECK (schedule_type IN ('SHIFT_START','INTERVAL','PER_EVENT','COVERAGE',
                                 'PRODUCT_CHANGE','POST_FAILURE','POST_ADJUSTMENT')),
    -- Durations as INTEGER seconds, not INTERVAL — keeps SQL Server path open.
    interval_seconds        INTEGER CHECK (interval_seconds IS NULL OR interval_seconds > 0),
    first_check_offset_seconds INTEGER NOT NULL DEFAULT 0,
    grace_seconds           INTEGER NOT NULL DEFAULT 0,
    post_failure_interval_seconds INTEGER CHECK (post_failure_interval_seconds IS NULL OR post_failure_interval_seconds > 0),
    coverage_rule      VARCHAR(200),
    effective_from     DATE NOT NULL,
    effective_to       DATE,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by         VARCHAR(64) NOT NULL,
    -- An INTERVAL schedule without an interval is meaningless.
    CONSTRAINT chk_interval_has_period
        CHECK (schedule_type <> 'INTERVAL' OR interval_seconds IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_schedule_revision ON qc.schedule_rule (revision_id);

-- -----------------------------------------------------------------------------
-- CALIBRATION
-- Framework metric: "Calibration risk — Expired and due-soon instruments USED BY
-- inspection process." The adversarial review correctly found that an
-- unreferenced calibration table makes that report unwritable. qc.inspection
-- carries instrument_id so the report is a join, not a guess.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS qc.equipment_calibration (
    instrument_id     VARCHAR(64) PRIMARY KEY,
    description       VARCHAR(200),
    station_id        VARCHAR(32),
    last_calibrated   DATE,
    calibration_due   DATE,
    cal_status        VARCHAR(16) NOT NULL DEFAULT 'VALID'
        CHECK (cal_status IN ('VALID','DUE_SOON','EXPIRED','OUT_OF_SERVICE')),
    evidence_ref      VARCHAR(300),
    retired_at        TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_cal_due ON qc.equipment_calibration (calibration_due)
    WHERE retired_at IS NULL;

-- -----------------------------------------------------------------------------
-- CROSS-STAGE TRACKING (framework section 7)
-- Level 1 = correlation, Level 2 = Production Tracking ID. This schema is
-- Level-2-ready now; nothing forces Level 2 to be populated before the
-- tracking ID format is agreed with production and QC.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS qc.tracking_unit (
    tracking_unit_id  BIGSERIAL PRIMARY KEY,
    -- The agreed Production Tracking ID. NULL until Level 2 is commissioned —
    -- an inspection can still be recorded and correlated at Level 1 without it.
    tracking_ref      VARCHAR(64),
    process_stage     VARCHAR(50) NOT NULL
        CHECK (process_stage IN ('VENEER_PREPARATION','VENEER_ASSEMBLY',
                                 'LAYUP_AND_PRESS','FINISHING','TOOLING')),
    stage_unit_type   VARCHAR(16) NOT NULL
        CHECK (stage_unit_type IN ('PACK','LOAD','CART','BATCH','ORDER')),
    stage_unit_ref    VARCHAR(64) NOT NULL,
    line_id           VARCHAR(32) NOT NULL REFERENCES qc.lines(line_id),
    station_id        VARCHAR(32),
    product_code      VARCHAR(64),
    grade_code        VARCHAR(32),
    nominal_thickness NUMERIC(6,2),
    production_order  VARCHAR(64),
    started_at        TIMESTAMPTZ,
    finished_at       TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT chk_tracking_times CHECK (finished_at IS NULL OR started_at IS NULL OR started_at <= finished_at)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_tracking_ref
    ON qc.tracking_unit (tracking_ref) WHERE tracking_ref IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tracking_stage_unit ON qc.tracking_unit (stage_unit_type, stage_unit_ref);
CREATE INDEX IF NOT EXISTS idx_tracking_correlate  ON qc.tracking_unit (line_id, product_code, started_at);

-- Parent/child links representing splits and combinations
-- (LP-042 -> DL-118 -> CP-301/CP-302 -> LU-094 -> FP-441/FP-442).
CREATE TABLE IF NOT EXISTS qc.tracking_link (
    link_id          BIGSERIAL PRIMARY KEY,
    parent_unit_id   BIGINT NOT NULL REFERENCES qc.tracking_unit(tracking_unit_id),
    child_unit_id    BIGINT NOT NULL REFERENCES qc.tracking_unit(tracking_unit_id),
    -- Framework: "CORRELATION IS NOT GENEALOGY ... The system must not imply
    -- that an upstream record caused a downstream result when the linkage is
    -- only date, product and shift proximity." link_type is what the UI's
    -- LinkQualityIndicator reads to say so honestly.
    link_type        VARCHAR(24) NOT NULL
        CHECK (link_type IN ('GENEALOGY_SCANNED','GENEALOGY_ENTERED','CORRELATION_INFERRED')),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by       VARCHAR(64) NOT NULL,
    CONSTRAINT uq_tracking_link UNIQUE (parent_unit_id, child_unit_id),
    CONSTRAINT chk_no_self_link CHECK (parent_unit_id <> child_unit_id)
);
CREATE INDEX IF NOT EXISTS idx_link_parent ON qc.tracking_link (parent_unit_id);
CREATE INDEX IF NOT EXISTS idx_link_child  ON qc.tracking_link (child_unit_id);

-- -----------------------------------------------------------------------------
-- INSPECTION RECORD
-- Header context columns (line, shift, station, product, grade, nominal,
-- pack/load, revision) are carried HERE, not joined in. Framework 4.1 requires
-- them permanently visible, and section 15 requires compliance grouped "by
-- process, form, shift, day/week/month, technician and product". Both
-- delegated reviewers independently flagged their absence as a real defect.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS qc.inspection (
    inspection_id     BIGSERIAL PRIMARY KEY,
    -- Framework rule: "Use database-generated inspection IDs and an idempotency
    -- key to prevent duplicate saves." Client generates this before first save;
    -- a retry collides and is caught, so a double-tap cannot create two records.
    -- Kept globally UNIQUE deliberately: a dedup token scoped per form would
    -- not dedup a retry that re-resolved to a different revision.
    idempotency_key   UUID NOT NULL UNIQUE,
    revision_id       BIGINT NOT NULL REFERENCES qc.form_revision(revision_id),
    tracking_unit_id  BIGINT REFERENCES qc.tracking_unit(tracking_unit_id),
    instrument_id     VARCHAR(64) REFERENCES qc.equipment_calibration(instrument_id),

    -- ---- header context (always visible, always reportable) ----
    line_id           VARCHAR(32) NOT NULL REFERENCES qc.lines(line_id),
    station_id        VARCHAR(32) NOT NULL,
    shift_code        VARCHAR(16) NOT NULL
        CHECK (shift_code IN ('DAY','AFTERNOON','NIGHT')),
    product_code      VARCHAR(64),
    grade_code        VARCHAR(32),
    nominal_thickness NUMERIC(6,2),
    pack_load_ref     VARCHAR(64),

    -- ---- state ----
    inspection_state  VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
        CHECK (inspection_state IN ('DRAFT','SUBMITTED','AMENDED','CANCELLED')),
    overall_result    VARCHAR(16)
        CHECK (overall_result IS NULL OR overall_result IN ('PASS','WARNING','FAIL')),

    -- ---- times: framework rule "Record sample time separately from submitted
    -- time and corrected time." ----
    sample_time       TIMESTAMPTZ NOT NULL,
    submitted_at      TIMESTAMPTZ,
    corrected_at      TIMESTAMPTZ,

    -- ---- people ----
    -- created_by is the draft author and is always known.
    -- submitted_by is NULL until submission — a draft has no submitter. Both
    -- reviewers flagged the original NOT NULL submitted_by + DRAFT default as
    -- mutually exclusive; this is the fix.
    created_by        VARCHAR(64) NOT NULL,
    submitted_by      VARCHAR(64),
    corrected_by      VARCHAR(64),
    amends_inspection_id BIGINT REFERENCES qc.inspection(inspection_id),

    comments          TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- A submitted inspection must have a submitter, a submit time and a result.
    CONSTRAINT chk_submitted_complete CHECK (
        inspection_state <> 'SUBMITTED'
        OR (submitted_by IS NOT NULL AND submitted_at IS NOT NULL AND overall_result IS NOT NULL)
    ),
    -- Framework: "Submitted results are immutable to ordinary users;
    -- corrections create a controlled amendment." An AMENDED record must say
    -- what it amends and why.
    CONSTRAINT chk_amendment_traceable CHECK (
        inspection_state <> 'AMENDED'
        OR (amends_inspection_id IS NOT NULL AND corrected_by IS NOT NULL AND corrected_at IS NOT NULL)
    )
);
CREATE INDEX IF NOT EXISTS idx_insp_compliance
    ON qc.inspection (line_id, station_id, shift_code, sample_time);
CREATE INDEX IF NOT EXISTS idx_insp_revision   ON qc.inspection (revision_id, sample_time);
CREATE INDEX IF NOT EXISTS idx_insp_tracking   ON qc.inspection (tracking_unit_id);
CREATE INDEX IF NOT EXISTS idx_insp_open_drafts
    ON qc.inspection (created_by, created_at) WHERE inspection_state = 'DRAFT';
CREATE INDEX IF NOT EXISTS idx_insp_product    ON qc.inspection (product_code, sample_time);

-- -----------------------------------------------------------------------------
-- MEASUREMENT — carries the applied specification SNAPSHOT.
-- Framework rule (non-negotiable): "Store the specification values applied at
-- submission; historical pass/fail must not change when a future specification
-- changes." applied_* columns are the snapshot and are what every report and
-- trend chart MUST read. specification_id is retained for audit traceability
-- only ("which rule was used") — it is safe because specifications are
-- soft-retired and effective-dated, never mutated in place, but no report
-- should join through it for limits.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS qc.measurement (
    measurement_id    BIGSERIAL PRIMARY KEY,
    inspection_id     BIGINT NOT NULL REFERENCES qc.inspection(inspection_id),
    characteristic_id BIGINT NOT NULL REFERENCES qc.characteristic_definition(characteristic_id),
    specification_id  BIGINT REFERENCES qc.specification(specification_id),

    value_numeric     NUMERIC(12,4),
    value_text        VARCHAR(300),
    value_boolean     BOOLEAN,
    is_calculated     BOOLEAN NOT NULL DEFAULT FALSE,

    -- ---- APPLIED LIMIT SNAPSHOT ----
    applied_min       NUMERIC(12,4),
    applied_target    NUMERIC(12,4),
    applied_max       NUMERIC(12,4),
    applied_warn_inset NUMERIC(12,4),
    applied_unit      VARCHAR(30),

    result            VARCHAR(16) NOT NULL DEFAULT 'NOT_ENTERED'
        CHECK (result IN ('NOT_ENTERED','PASS','WARNING','FAIL','NOT_APPLICABLE')),
    deviation         NUMERIC(12,4),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_measurement UNIQUE (inspection_id, characteristic_id)
);
CREATE INDEX IF NOT EXISTS idx_meas_inspection ON qc.measurement (inspection_id);
CREATE INDEX IF NOT EXISTS idx_meas_trend      ON qc.measurement (characteristic_id, created_at);
CREATE INDEX IF NOT EXISTS idx_meas_failures   ON qc.measurement (characteristic_id)
    WHERE result IN ('FAIL','WARNING');

-- -----------------------------------------------------------------------------
-- NON-CONFORMANCE + WORKFLOW
-- Framework 12.1 state model. No hold_until column: HOLD is released by a
-- disposition EVENT, not on a scheduled date. The original design's
-- CHECK forcing a hold_until timestamp whenever state = HOLD would have made
-- staff invent a fake release date to satisfy the constraint — both reviewers
-- independently called this out.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS qc.nonconformance (
    nonconformance_id BIGSERIAL PRIMARY KEY,
    inspection_id     BIGINT NOT NULL REFERENCES qc.inspection(inspection_id),
    measurement_id    BIGINT REFERENCES qc.measurement(measurement_id),
    tracking_unit_id  BIGINT REFERENCES qc.tracking_unit(tracking_unit_id),
    severity          VARCHAR(16) NOT NULL
        CHECK (severity IN ('MINOR','MAJOR','CRITICAL')),
    nc_state          VARCHAR(24) NOT NULL DEFAULT 'OPEN'
        CHECK (nc_state IN ('OPEN','RECHECK_REQUIRED','ESCALATED','HOLD',
                            'ACTION_IN_PROGRESS','VERIFICATION_REQUIRED',
                            'QC_REVIEW','CLOSED','CANCELLED')),
    is_on_hold        BOOLEAN NOT NULL DEFAULT FALSE,
    hold_placed_at    TIMESTAMPTZ,
    hold_placed_by    VARCHAR(64),
    hold_released_at  TIMESTAMPTZ,
    hold_released_by  VARCHAR(64),
    affected_qty      NUMERIC(12,2),
    affected_units    VARCHAR(300),
    disposition       VARCHAR(32)
        CHECK (disposition IS NULL OR disposition IN ('USE_AS_IS','REWORK','REGRADE','SCRAP','RETURN_TO_SUPPLIER')),
    assigned_to       VARCHAR(64),
    opened_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at         TIMESTAMPTZ,
    closed_by         VARCHAR(64),
    -- CANCELLED is for an authorised duplicate/invalid workflow only and must
    -- carry a reason. Framework: "never as a method of erasing evidence."
    cancel_reason     VARCHAR(300),
    CONSTRAINT chk_hold_consistency CHECK (
        (is_on_hold = FALSE) OR (hold_placed_at IS NOT NULL AND hold_placed_by IS NOT NULL)
    ),
    CONSTRAINT chk_hold_release CHECK (
        hold_released_at IS NULL OR (hold_released_by IS NOT NULL AND hold_placed_at IS NOT NULL)
    ),
    CONSTRAINT chk_closed_complete CHECK (
        nc_state <> 'CLOSED' OR (closed_at IS NOT NULL AND closed_by IS NOT NULL AND disposition IS NOT NULL)
    ),
    CONSTRAINT chk_cancel_reasoned CHECK (
        nc_state <> 'CANCELLED' OR cancel_reason IS NOT NULL
    )
);
CREATE INDEX IF NOT EXISTS idx_nc_queue ON qc.nonconformance (nc_state, severity, opened_at);
CREATE INDEX IF NOT EXISTS idx_nc_hold  ON qc.nonconformance (is_on_hold, opened_at) WHERE is_on_hold = TRUE;
CREATE INDEX IF NOT EXISTS idx_nc_insp  ON qc.nonconformance (inspection_id);

CREATE TABLE IF NOT EXISTS qc.workflow_event (
    event_id          BIGSERIAL PRIMARY KEY,
    nonconformance_id BIGINT NOT NULL REFERENCES qc.nonconformance(nonconformance_id),
    event_type        VARCHAR(24) NOT NULL
        CHECK (event_type IN ('RECHECK','NOTIFICATION','ACKNOWLEDGEMENT','ACTION',
                              'DISPOSITION','VERIFICATION','HOLD_PLACED','HOLD_RELEASED',
                              'ESCALATION','STATE_CHANGE')),
    from_state        VARCHAR(24),
    to_state          VARCHAR(24),
    recheck_number    INTEGER CHECK (recheck_number IS NULL OR recheck_number > 0),
    recheck_inspection_id BIGINT REFERENCES qc.inspection(inspection_id),
    notes             VARCHAR(500),
    actor             VARCHAR(64) NOT NULL,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wf_nc ON qc.workflow_event (nonconformance_id, occurred_at);

-- -----------------------------------------------------------------------------
-- AUDIT — append-only. Framework: high-value events are specification approval,
-- correction, disposition and release.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS qc.audit_event (
    audit_id      BIGSERIAL PRIMARY KEY,
    entity_table  VARCHAR(64) NOT NULL,
    entity_id     BIGINT NOT NULL,
    action        VARCHAR(32) NOT NULL
        CHECK (action IN ('INSERT','UPDATE','SUBMIT','AMEND','APPROVE','ACTIVATE',
                          'SUPERSEDE','DISPOSITION','HOLD_PLACE','HOLD_RELEASE','CANCEL')),
    field_name    VARCHAR(64),
    old_value     TEXT,
    new_value     TEXT,
    reason        VARCHAR(300),
    actor         VARCHAR(64) NOT NULL,
    source        VARCHAR(32) NOT NULL DEFAULT 'PERSPECTIVE'
        CHECK (source IN ('PERSPECTIVE','GATEWAY_SCRIPT','DESIGNER','MIGRATION','EXTERNAL')),
    occurred_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON qc.audit_event (entity_table, entity_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_actor  ON qc.audit_event (actor, occurred_at);

-- =============================================================================
-- SPECIFICATION RESOLVER
-- Framework 11.2: "Resolve the most specific approved specification matching
-- the active date, form revision, characteristic, product, grade, nominal
-- thickness, variant/veneer type and station. If ZERO or MULTIPLE equally valid
-- rules are found, block submission and raise a configuration exception rather
-- than guessing."
--
-- Returns 0, 1, or >1 rows. The caller MUST treat 0 and >1 as blocking
-- configuration errors. The function does not pick a winner on a tie — that is
-- the entire point.
-- =============================================================================
CREATE OR REPLACE FUNCTION qc.resolve_specification(
    p_characteristic_id BIGINT,
    p_product_code      VARCHAR(64),
    p_grade_code        VARCHAR(32),
    p_nominal_thickness NUMERIC(6,2),
    p_variant           VARCHAR(50),
    p_station_id        VARCHAR(32),
    p_as_of             DATE
)
RETURNS TABLE (
    specification_id BIGINT,
    min_value        NUMERIC(12,4),
    target_value     NUMERIC(12,4),
    max_value        NUMERIC(12,4),
    warn_inset       NUMERIC(12,4),
    unit             VARCHAR(30),
    specificity      INTEGER
)
LANGUAGE sql STABLE AS $$
    WITH matched AS (
        SELECT s.specification_id, s.min_value, s.target_value, s.max_value,
               s.warn_inset, s.unit,
               (CASE WHEN s.product_code      IS NOT NULL THEN 16 ELSE 0 END
              + CASE WHEN s.grade_code        IS NOT NULL THEN 8  ELSE 0 END
              + CASE WHEN s.nominal_thickness IS NOT NULL THEN 4  ELSE 0 END
              + CASE WHEN s.variant           IS NOT NULL THEN 2  ELSE 0 END
              + CASE WHEN s.station_id        IS NOT NULL THEN 1  ELSE 0 END) AS specificity
        FROM qc.specification s
        WHERE s.characteristic_id = p_characteristic_id
          AND s.lifecycle_state = 'ACTIVE'
          AND s.effective_from <= p_as_of
          AND (s.effective_to IS NULL OR s.effective_to >= p_as_of)
          AND (s.product_code      IS NULL OR s.product_code      = p_product_code)
          AND (s.grade_code        IS NULL OR s.grade_code        = p_grade_code)
          AND (s.nominal_thickness IS NULL OR s.nominal_thickness = p_nominal_thickness)
          AND (s.variant           IS NULL OR s.variant           = p_variant)
          AND (s.station_id        IS NULL OR s.station_id        = p_station_id)
    )
    SELECT m.specification_id, m.min_value, m.target_value, m.max_value,
           m.warn_inset, m.unit, m.specificity
    FROM matched m
    WHERE m.specificity = (SELECT MAX(m2.specificity) FROM matched m2);
$$;

COMMENT ON FUNCTION qc.resolve_specification IS
'Returns every ACTIVE specification tied for most-specific match. Caller MUST
block submission and raise a configuration exception on 0 rows (no rule) or
>1 rows (ambiguous rules). Never silently picks a winner — framework 11.2.';

-- =============================================================================
-- END 003
-- =============================================================================
