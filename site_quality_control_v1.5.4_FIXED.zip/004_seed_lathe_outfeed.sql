-- =============================================================================
-- Migration 004 (v2) | Seed: Lathe Outfeed pilot form -- REAL SOURCED VALUES
-- =============================================================================
-- Supersedes the first 004, which used [ASSUMED -- NOT VERIFIED] placeholders
-- because the controlled sheet had not been supplied. Every value below is
-- read directly from "Lathe Outfeed Process Control Sheet", Reference
-- 05-20-39, Issue Date 27 Feb 2026 (uploaded 17 Jul 2026), extracted with a
-- formula-and-cached-value pass so nothing is eyeballed off a screenshot.
--
-- SCOPE, per your Level 1 instruction: only the NUMERIC characteristics are
-- seeded here. The real sheet also has three ATTRIBUTE-type fields --
-- Moisture Grade (HI / LOW SAP / SAP), Tight (G/F/P), Scribe (G/F/P) -- which
-- the current renderer cannot display correctly yet (see the note at the
-- bottom of this file). Seeding them now would put broken rows in front of an
-- operator, so they are deliberately left out until that gap is closed.
-- =============================================================================

INSERT INTO qc.lines (line_id, description)
VALUES ('MYRTLEFORD_L1', 'Myrtleford Plywood Line 1')
ON CONFLICT (line_id) DO NOTHING;

INSERT INTO qc.form_definition (form_code, title, doc_reference, business_owner,
                                process_stage, form_family, created_by)
VALUES ('LATHE_OUTFEED', 'Lathe Outfeed Process Control',
        '05-20-39 (issued 27 Feb 2026)', 'TBD -- QC Manager',
        'VENEER_PREPARATION', 'DIMENSIONAL', 'migration_004_v2')
ON CONFLICT (form_code) DO UPDATE SET doc_reference = EXCLUDED.doc_reference;

INSERT INTO qc.form_revision (form_id, revision_label, lifecycle_state,
                              effective_from, created_by)
SELECT form_id, 'A', 'DRAFT', CURRENT_DATE, 'migration_004_v2'
FROM qc.form_definition WHERE form_code = 'LATHE_OUTFEED'
ON CONFLICT (form_id, revision_label) DO NOTHING;

-- -----------------------------------------------------------------------------
-- Sections, in the sheet's own left-to-right column order (Time / Moist /
-- Thickness / Clipping Width / Diagonal Diff / Scribe).
-- -----------------------------------------------------------------------------
INSERT INTO qc.section_definition (revision_id, section_code, title, display_order)
SELECT fr.revision_id, v.code, v.title, v.ord
FROM qc.form_revision fr
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
CROSS JOIN (VALUES
    ('THICKNESS',      'Thickness',       1),
    ('CLIPPING_WIDTH',  'Clipping width',  2),
    ('SQUARENESS',      'Squareness (diagonal)', 3),
    ('SCRIBE',          'Scribe',          4)
) AS v(code, title, ord)
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A'
ON CONFLICT (revision_id, section_code) DO NOTHING;

-- -----------------------------------------------------------------------------
-- Characteristics
-- Order and position codes match the sheet exactly: columns D/E/F are headed
-- RHS/MID/LHS in that order (not LHS/MID/RHS as the first draft of this
-- migration guessed) -- matching operator muscle memory on the printed form
-- matters more than an internally "tidy" left-to-right ordering.
-- -----------------------------------------------------------------------------
INSERT INTO qc.characteristic_definition
    (section_id, characteristic_code, label, data_type, unit, precision_dp,
     position_code, display_order, is_required, failure_message)
SELECT sd.section_id, v.code, v.label, 'NUMERIC', v.unit, v.dp, v.pos, v.ord,
       TRUE, v.msg
FROM qc.section_definition sd
JOIN qc.form_revision fr ON fr.revision_id = sd.revision_id
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
CROSS JOIN (VALUES
    -- section_code,   char_code,          label,                unit, dp, pos,   order, failure_message
    ('THICKNESS',     'THICKNESS_RHS',    'Thickness RHS',       'mm', 2, 'RHS', 1, 'Green veneer thickness outside specification.'),
    ('THICKNESS',     'THICKNESS_MID',    'Thickness MID',       'mm', 2, 'MID', 2, 'Green veneer thickness outside specification.'),
    ('THICKNESS',     'THICKNESS_LHS',    'Thickness LHS',       'mm', 2, 'LHS', 3, 'Green veneer thickness outside specification.'),
    ('CLIPPING_WIDTH','CLIP_WIDTH_RHS',   'Clipping width RHS',  'mm', 0, 'RHS', 1, 'Clipping width outside specification for the selected grade.'),
    ('CLIPPING_WIDTH','CLIP_WIDTH_MID',   'Clipping width MID',  'mm', 0, 'MID', 2, 'Clipping width outside specification for the selected grade.'),
    ('CLIPPING_WIDTH','CLIP_WIDTH_LHS',   'Clipping width LHS',  'mm', 0, 'LHS', 3, 'Clipping width outside specification for the selected grade.'),
    -- Diagonal Diff: two raw corner-to-corner readings, no individual limit --
    -- only their difference is judged, and only against a fixed 15mm max.
    ('SQUARENESS',    'DIAGONAL_1',       'Diagonal 1st',        'mm', 0, NULL,  1, NULL),
    ('SQUARENESS',    'DIAGONAL_2',       'Diagonal 2nd',        'mm', 0, NULL,  2, NULL),
    ('SCRIBE',        'SCRIBE_LENGTH',    'Scribe length',       'mm', 0, NULL,  1, 'Scribe length outside specification -- see next required action.')
) AS v(section_code, code, label, unit, dp, pos, ord, msg)
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A'
  AND sd.section_code = v.section_code
ON CONFLICT (section_id, characteristic_code) DO NOTHING;

-- A calculated characteristic: DIAGONAL_DIFF = |diagonal_1 - diagonal_2|.
-- Framework/schema already supports this via qc.measurement.is_calculated;
-- computing and submitting the derived value is renderer work, flagged below.
INSERT INTO qc.characteristic_definition
    (section_id, characteristic_code, label, data_type, unit, precision_dp,
     position_code, display_order, is_required, failure_message)
SELECT sd.section_id, 'DIAGONAL_DIFF', 'Diagonal difference', 'NUMERIC', 'mm', 0,
       NULL, 3, TRUE, 'Diagonal difference exceeds the 15mm squareness limit.'
FROM qc.section_definition sd
JOIN qc.form_revision fr ON fr.revision_id = sd.revision_id
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A'
  AND sd.section_code = 'SQUARENESS'
ON CONFLICT (section_id, characteristic_code) DO NOTHING;

-- -----------------------------------------------------------------------------
-- Specifications -- REAL values from the controlled sheet. Still seeded DRAFT:
-- a source document with a reference number is not the same as this system's
-- own approval event. Framework 11.4: a specification becomes ACTIVE only
-- when APPROVED (approved_by + approved_at), and I have neither -- fabricating
-- an approver identity would violate Rule 1. QC Manager needs to action the
-- activation steps at the bottom of this file.
-- -----------------------------------------------------------------------------

-- Green Thickness Spec (sheet section N6:P10). Two rows in the source, with
-- NO explicit nominal-thickness label on either row -- this is an INFERENCE,
-- not an extracted fact: 2.49-2.75mm (target 2.59) is assigned to the 2.4mm
-- nominal product line, and 3.01-3.33mm (target 3.22) to the 3.0mm nominal
-- product line, purely because each range brackets that product's name.
-- [INFERRED -- CONFIRM WITH QC] Please confirm this pairing is correct.
INSERT INTO qc.specification
    (characteristic_id, product_code, grade_code, nominal_thickness, variant,
     station_id, min_value, target_value, max_value, warn_inset, unit,
     lifecycle_state, effective_from, created_by)
SELECT cd.characteristic_id, NULL, NULL, v.nominal, NULL, 'LATHE_OUTFEED',
       v.min_v, v.target_v, v.max_v, NULL, 'mm', 'DRAFT', CURRENT_DATE, 'migration_004_v2'
FROM qc.characteristic_definition cd
JOIN qc.section_definition sd ON sd.section_id = cd.section_id
JOIN qc.form_revision fr ON fr.revision_id = sd.revision_id
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
CROSS JOIN (VALUES
    (2.40, 2.49, 2.59, 2.75),   -- [INFERRED nominal] sheet row 9
    (3.00, 3.01, 3.22, 3.33)    -- [INFERRED nominal] sheet row 10
) AS v(nominal, min_v, target_v, max_v)
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A'
  AND cd.characteristic_code IN ('THICKNESS_RHS','THICKNESS_MID','THICKNESS_LHS');

-- Clipping Width Spec (sheet section G6:L11). Grade-dependent; SAP grade is
-- additionally nominal-thickness-dependent (HI and LOW SAP are not -- the
-- sheet's own H8:I8 merge explicitly says "2.4mm and 3.0mm" for both, i.e.
-- one limit regardless of nominal). Units inferred as mm: not explicitly
-- labeled on this block (unlike Green Thickness, which says "Measurements in
-- MM" outright), but 1100-1380 is dimensionally consistent with a veneer
-- sheet clipping width in mm and with every other measurement on this sheet.
-- [INFERRED unit -- confirm]
INSERT INTO qc.specification
    (characteristic_id, product_code, grade_code, nominal_thickness, variant,
     station_id, min_value, target_value, max_value, warn_inset, unit,
     lifecycle_state, effective_from, created_by)
SELECT cd.characteristic_id, NULL, v.grade, v.nominal, NULL, 'LATHE_OUTFEED',
       v.min_v, v.target_v, v.max_v, NULL, 'mm', 'DRAFT', CURRENT_DATE, 'migration_004_v2'
FROM qc.characteristic_definition cd
JOIN qc.section_definition sd ON sd.section_id = cd.section_id
JOIN qc.form_revision fr ON fr.revision_id = sd.revision_id
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
CROSS JOIN (VALUES
    -- grade,      nominal, min,   target, max     -- sheet cell refs
    ('HI',          NULL,    1100.0, 1345.0, 1355.0),  -- H9:H11, both nominals
    ('LOW_SAP',     NULL,    1340.0, 1350.0, 1360.0),  -- I9:I11, both nominals
    ('SAP',         2.40,    1360.0, 1370.0, 1380.0),  -- K9:K11, 2.4mm only
    ('SAP',         3.00,    1355.0, 1365.0, 1375.0)   -- L9:L11, 3.0mm only
) AS v(grade, nominal, min_v, target_v, max_v)
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A'
  AND cd.characteristic_code IN ('CLIP_WIDTH_RHS','CLIP_WIDTH_MID','CLIP_WIDTH_LHS');

-- Diagonal Diff: the sheet gives ONE fixed limit (max 15mm), not a
-- grade/nominal-dependent table -- min=NULL (only an upper bound exists),
-- target=0 (a perfectly square panel).
INSERT INTO qc.specification
    (characteristic_id, product_code, grade_code, nominal_thickness, variant,
     station_id, min_value, target_value, max_value, warn_inset, unit,
     lifecycle_state, effective_from, created_by)
SELECT cd.characteristic_id, NULL, NULL, NULL, NULL, 'LATHE_OUTFEED',
       NULL, 0, 15, NULL, 'mm', 'DRAFT', CURRENT_DATE, 'migration_004_v2'
FROM qc.characteristic_definition cd
JOIN qc.section_definition sd ON sd.section_id = cd.section_id
JOIN qc.form_revision fr ON fr.revision_id = sd.revision_id
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A'
  AND cd.characteristic_code = 'DIAGONAL_DIFF';

-- Scribed Length Spec (sheet section M33:P35). Flagged, not smoothed over:
-- the sheet labels nominal as "2400mm" but min/target/max are 2535/2545/2570
-- -- roughly 135-170mm ABOVE the stated nominal. That gap is too large to be
-- ordinary measurement tolerance. A plausible explanation is that "scribe
-- length" is an oversize pre-trim mark rather than the finished panel length,
-- but that is a guess, not something the sheet states.
-- [FLAG -- CONFIRM WITH QC] the nominal/limit relationship as printed.
INSERT INTO qc.specification
    (characteristic_id, product_code, grade_code, nominal_thickness, variant,
     station_id, min_value, target_value, max_value, warn_inset, unit,
     lifecycle_state, effective_from, created_by)
SELECT cd.characteristic_id, NULL, NULL, NULL, NULL, 'LATHE_OUTFEED',
       2535, 2545, 2570, NULL, 'mm', 'DRAFT', CURRENT_DATE, 'migration_004_v2'
FROM qc.characteristic_definition cd
JOIN qc.section_definition sd ON sd.section_id = cd.section_id
JOIN qc.form_revision fr ON fr.revision_id = sd.revision_id
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A'
  AND cd.characteristic_code = 'SCRIBE_LENGTH';

-- -----------------------------------------------------------------------------
-- Schedule: sheet header states "1 HOURLY OR LESS AS DESCRIBED. First check
-- to be done within 1/2hr of start of shift." Matches what was already seeded.
-- New from the sheet: "at least one Hi and one LS [Low Sap] pack must be
-- checked per shift regardless of set frequency" -- a COVERAGE rule the
-- schema has a column for (coverage_rule) but is not yet enforced by any
-- script. Recorded as data; not yet acted on.
-- -----------------------------------------------------------------------------
INSERT INTO qc.schedule_rule
    (revision_id, station_id, schedule_type, interval_seconds,
     first_check_offset_seconds, grace_seconds, post_failure_interval_seconds,
     coverage_rule, effective_from, created_by)
SELECT fr.revision_id, 'LATHE_OUTFEED', 'INTERVAL', 3600, 1800, 600, 1800,
       'At least one HI-grade pack and one LOW SAP pack checked per shift, '
       'regardless of the hourly schedule (sheet requirement, not yet enforced).',
       CURRENT_DATE, 'migration_004_v2'
FROM qc.form_revision fr
JOIN qc.form_definition fd ON fd.form_id = fr.form_id
WHERE fd.form_code = 'LATHE_OUTFEED' AND fr.revision_label = 'A';

INSERT INTO qc.equipment_calibration
    (instrument_id, description, station_id, last_calibrated, calibration_due, cal_status)
VALUES ('GAUGE-LATHE-01',
        'Thickness gauge, Lathe Outfeed. [STILL ASSUMED] the sheet has a blank '
        '"Thickness Gauge: ____" field filled in by hand per shift -- there is '
        'no fixed asset ID on the controlled document itself.',
        'LATHE_OUTFEED', NULL, NULL, 'VALID')
ON CONFLICT (instrument_id) DO NOTHING;

-- =============================================================================
-- KNOWN GAP -- renderer cannot show this form completely yet
-- The controlled sheet has THREE attribute-type fields not seeded here:
--   - Moisture Grade (HI / LOW SAP / SAP) -- a selector that determines which
--     Clipping Width specification row applies. This is a real dependency:
--     the Clipping Width spec resolver needs grade_code, and nothing currently
--     supplies it -- there is no grade selector on the page at all yet.
--   - Tight (G/F/P) and Scribe (G/F/P) -- categorical quality ratings.
-- shared/NumericMeasurement only handles data_type='NUMERIC'. The Flex
-- Repeater's props.path is hardcoded to that one component for every
-- instance, so an ATTRIBUTE row would currently render as a broken numeric
-- entry field. Seeding these three characteristics now would put visibly
-- broken fields in front of an operator, so they are deliberately withheld.
--
-- Closing this gap needs: an AttributeMeasurement component (dropdown/segment
-- control), and the Flex Repeater transform routing to the right component by
-- data_type. Also, the Moisture Grade selection needs to reach the
-- specification resolver for Clipping Width, which currently resolves with
-- gradeCode=NULL for every instance -- until a selector exists, Clipping
-- Width will only ever match the HI/LOW SAP wildcard-nominal rows correctly
-- if grade is supplied some other way.
--
-- TO ACTIVATE THIS FORM (QC Manager, after confirming the flagged items above):
--   1. Resolve [INFERRED]/[FLAG] items against QC's own copy of 05-20-39.
--   2. UPDATE qc.specification SET lifecycle_state='ACTIVE', approved_by=?,
--        approved_at=now() WHERE ... (per specification, once confirmed)
--   3. UPDATE qc.form_revision SET lifecycle_state='ACTIVE', approved_by=?,
--        approved_at=now() WHERE ...
-- =============================================================================
