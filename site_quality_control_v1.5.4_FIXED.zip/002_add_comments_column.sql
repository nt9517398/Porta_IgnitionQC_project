-- Migration 002: add optional comments field to all 3 quality tables.
-- Safe to run against a database that already has 001 applied and has data
-- in it -- comments is nullable, no backfill needed, no existing row is
-- affected.

ALTER TABLE qc.lathe_quality          ADD COLUMN IF NOT EXISTS comments TEXT;
ALTER TABLE qc.dryer_quality          ADD COLUMN IF NOT EXISTS comments TEXT;
ALTER TABLE qc.finished_panel_quality ADD COLUMN IF NOT EXISTS comments TEXT;
