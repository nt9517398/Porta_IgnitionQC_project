# CHANGELOG v1.5.3 — Framework re-architecture (Level 1 pilot)

Aligned to **Ignition QC Process Control System, Complete project framework, Draft 0.2** (16 Jul 2026), which is authoritative and supersedes prior versions where they conflict.

**Delta from v1.4:** architectural replacement, not a patch. **Confidence shift:** materially up on mechanism (three core Perspective structures now verified against real committed code rather than assumed), unchanged on live-import (still no Designer in this environment).

---

## The finding that forced this version

The framework's own risk register, row 1:

> One-off pages proliferate → High maintenance and inconsistent rules → **Mitigation: Configuration-driven renderer and shared components.**

v1.4 was exactly that anti-pattern: 4 hardcoded station pages over 3 wide one-table-per-station schemas. The plant has ~15 forms across 10 areas. v1.4 does not reach production, so v1.5.3 re-architects rather than restyles.

**The test that matters:** in v1.4, form #2 = a new table + a new page. In v1.5.3, form #2 = an `INSERT`. `004_seed_lathe_outfeed.sql` is an insert script, not DDL — that is the whole point.

---

## Critical correction to my own earlier work: script indentation

**Every embedded script in this project was broken, and I broke them.**

In v1.2 I "fixed" an `IndentationError` across 8 scripts by stripping leading tabs. That was wrong. Perspective wraps event scripts as `def runAction(self, event):` and transforms as a function body — so the body **must** be tab-indented. I had validated with `ast.parse` on the raw body, which *always* throws `IndentationError` regardless of correctness. **The oracle was the bug**, and I "fixed" correct code to satisfy it.

Evidence (real git-committed Ignition project): **4 of 4** scripts start with a tab; **0** are unindented. Example: `"script": "\tself.custom.focused = False"`.

Every button in v1.2–v1.4 would have thrown `IndentationError` on click. It was never reported because the forms failed to render before anyone could press Enter.

- Verification method corrected to **wrap-then-parse**.
- All 10 scripts re-indented. **17/17 now pass.**

## Second correction: `style.classes` is a string

Real exports use `"classes": "typo/font/basic typo/truncate"` — a **space-separated string**. Zero array-form instances exist in the reference repo. v1.4 had **45 array-form instances**; all converted. This also independently confirms the framework's Appendix A binding (which concatenates `'qcFieldFail' + ' qcPulseFail'`) was right all along.

## Third correction: the theme ships in the project now

`DEPLOYMENT.md` claimed the theme could not be exported and needed a manual Gateway filesystem step. The framework said the Advanced Stylesheet is project-scoped; IA's 8.1.22 notes confirm it, and IA's own docs state Gateway themes *"can't be exported with a project or gateway backup"*. Better still, **animated Style Classes** are verified project resources — real committed example with `keyframes` + `iterationCount`. **27 Style Classes** now ship inside the export. No Gateway step.

---

## Scope: Level 1 only (per your direction)

| Capability | v1.5.3 | Note |
|---|---|---|
| Config-driven render, entry, live status, transactional submit, shift log | **Built** | |
| Cross-stage Level 1 (correlate by line/product/shift/time) | **Built** — header columns on `qc.inspection` | No tracking ID needed |
| Level 2 tracking ID / Level 3 genealogy | Schema ready, **dormant** | `tracking_unit`/`tracking_link` unused |
| HOLD, notifications, stop-process, maintenance, verification, escalation | Schema allows, **dormant** | Nothing writes them |
| Pilot NC path | `OPEN → RECHECK_REQUIRED → QC_REVIEW → CLOSED` | Minimal path only |

The schema is a **superset** of Level 1 — nothing had to be torn out, only left dormant. Scaling to Level 2 later is additive, not a migration.

---

## Built

**`003_qc_framework_schema.sql`** — 14 entities, config-driven. Coexists with 001/002; **drops nothing** (live data + working Transaction Groups). Enforces the non-negotiables structurally:
- Applied limits **snapshotted** onto `qc.measurement` (`applied_min/target/max/warn_inset/unit`) — historical pass/fail cannot change when a spec changes.
- `idempotency_key UUID UNIQUE` — a retry collides and is caught as success.
- `qc.resolve_specification()` returns **0, 1, or >1 rows and never picks a winner** — ties are a blocking configuration error by design.
- Deliberately portable: **no ENUM, no JSONB, no INTERVAL columns**. Verified: 0 real occurrences of each.

**`QCF` project library** — the framework's *one status evaluation contract*. `evaluate_status()` is the only place PASS/WARNING/FAIL is decided, so an operator's field, the shift log beside it, and a manager KPI can never disagree.

**7 named queries**, **27 Style Classes** (framework tokens: Porta Red `#D7194B`, Charcoal `#343A40`, Yellow `#FFF200`, Green `#00E62E`, Purple `#9999FF`, Fail `#E53935`, Amber `#FFBF00`) — including `qcPulseFail`/`qcPulseWarning` with `iterationCount: "3"`, matching Appendix A exactly.

**`shared/NumericMeasurement`** + **`tech/lathe_outfeed`** — Flex Repeater renderer. All three mechanisms verified against real code: `ia.display.flex-repeater` / `props.instances` / `props.path`; tab-indented transforms; `messageHandlers` at **`root.scripts.messageHandlers`** with `pageScope`.

**Pulse needs no timer.** `iterationCount: 3` self-terminates; the persistent class remains. Returning to PASS changes the class string and drops the pulse class; a later transition back into FAIL changes it again and re-triggers naturally. This satisfies Appendix A ("pulse flag separate from status") with zero timer machinery.

---

## Orchestra: what the models contributed, and what they got wrong

**DeepSeek** produced the schema foundation — snapshot columns, idempotency, the specificity-ranked resolver, and the SQL Server delta list were all genuinely good, and it self-flagged the orphaned calibration table.

**GLM** audited it and confirmed 5 defects I suspected, plus one I missed: `qc_inspection_state` was a **phantom type** — referenced but never defined. That DDL would not have executed.

Applied: missing `shift_code`/`line_id` (compliance is reported *by shift*); `submitted_by NOT NULL` vs `DRAFT` default (a draft has no submitter); `chk_hold_state` forcing a fake `hold_until` (HOLD releases on an *event*); orphaned calibration (now `instrument_id` on `qc.inspection`); 9 ENUMs → VARCHAR+CHECK.

**Rejected, with reasons:**
- *Scope idempotency per form* — weakens it. A dedup token must be global; UUID collision is not a real failure mode.
- *Drop `spec_id`* — safe to keep. Specs are effective-dated and soft-retired, never mutated, so the FK points at an immutable row. Kept for audit traceability, with the rule that reports read `applied_*`.

**DeepSeek's renderer code had 8 real bugs, including a fabricated API** — `system.perspective.getState()` does not exist, and BLOCK 4 was built on it. Also `system.security.getUsername()` (Vision, not Perspective), `dict(row)` on a Dataset, `.get()` on a property-tree wrapper, and a `context` dict whose keys didn't match `submit_inspection` (instant KeyError). Rewritten: the parent holds resolved config in its own custom prop, so submit reads parent-local state and the fabrication is designed out entirely.

---

## Verification

```
JSON failures      : 0
script failures    : 0 (of 17)   [wrap-then-parse oracle]
QCF library        : OK
array-form classes : 0           [was 45]
undefined classes  : NONE        [was 9 dangling]
named queries      : 7/7 resolve
```

---

## Open items — need your decision, not my guess

1. **DB platform [UNRESOLVED].** Framework §16.3 says SQL Server; §19.1 lists platform as still-open; reality is PostgreSQL 14 with live data. DDL targets **PostgreSQL** (matching deployment) and lists every SQL Server delta in its header. Flagged, not silently chosen.
2. **Real Lathe Outfeed tolerances.** "Lathe Outfeed Process Control Sheet 27.02.2026" was not supplied. Seeded values (~3.05/3.20/3.35) are `[ASSUMED]` and seeded **DRAFT** — the resolver only matches ACTIVE, so **submission is blocked until QC approves real values**. A blocked form that says why beats a wrong tolerance that silently works.
3. **Superseded views.** `lathe`, `dryer_infeed`, `dryer_outfeed`, `finished_panel` still exist and are now redundant against `tech/lathe_outfeed`. Left in place deliberately until the pilot proves out; they should be retired, not kept in parallel.
4. **Reduced-motion.** Framework Appendix A wants `@media (prefers-reduced-motion: reduce)`. Style Classes are verified; the media-query shape on a Style Class is **not**. Needs the Advanced Stylesheet — mechanism confirmed, file structure unverified, so I did not guess it.

**Standing caveat:** verified against official IA docs and real working project exports, **not** against a live Designer import. The indentation and `classes` findings are exactly the class of error that only real-code comparison catches — worth importing this before building further on it.
