# CHANGELOG v1.3 — Gemba walk against real Ignition exports + orchestra_adversarial

## Why this pass exists

v1.2's biggest limitation was stated plainly in its own confidence notes: everything was verified against Inductive Automation's documentation *prose*, with no live Designer to import against. That's a real gap. This pass closes it as far as it can be closed without an actual Gateway: by finding genuine, public, git-committed Ignition Perspective projects on GitHub (`jlbcontrols/Flintium`, `joyja/ignition-framework` — both real, actively-used, confirmed-importable by construction) and diffing v1.2's reconstructed JSON directly against real, working bytes instead of documentation descriptions.

This found two real problems that documentation-only verification had missed.

## Root cause (kaizen-workflow Level 3, Step 1–2)

**Gemba walk finding:** the indirect-tag-binding fix in v1.2 was built from Designer GUI documentation describing an older/alternate authoring flow (numbered placeholders `{1}`, `{2}` + an array of typed reference objects). The real, confirmed-working shape in actual Ignition 8.x exports is structurally different: a **named** placeholder matching a key in a plain **object** (not array), with the reference value as a direct string, not a nested binding structure. Both shapes may exist somewhere in Ignition's binding history — but only one is confirmed by real, imported, working project files, so that's the one now in this project.

**Second finding, same walk:** `bidirectional` was placed as a sibling of `type`/`config` throughout the project (both in v1.1's own pre-existing shift-selector code and in v1.2's new fields, which copied that pattern). Two independent real examples — a tag binding and a property binding — both place it *inside* `config`. This was a latent bug inherited from before this audit even started, not something introduced by the fix pass, but propagated by it.

## Fixed

- **`measurement_field`'s indirect tag binding rebuilt** to the real confirmed shape:
  ```json
  {
    "type": "tag",
    "config": {
      "tagPath": "{tagPath}",
      "mode": "indirect",
      "bidirectional": false,
      "references": { "tagPath": "{view.params.tagPath}" }
    }
  }
  ```
  Resolved via `orchestra_adversarial`: DeepSeek and GLM independently proposed near-identical corrected JSON from the same real example (strong convergent signal), then cross-attacked each other. One attack (DeepSeek claiming the untouched `{view.params.decimals}`/`{view.params.unit}` expression transform was invalid syntax) was checked against real examples in the same repos and refuted — two genuine working transforms reference `view.params.*` the same way, so that part of the original code was never broken. Another (GLM claiming `overlayOptOut` mattered for runtime UX) was dropped after GLM's own two statements about it turned out to contradict each other — Round 1 called it "zero runtime effect," Round 2 called it a "runtime UX failure mode." Designer-time error visibility is arguably useful to keep, not suppress, anyway.
- **`bidirectional` moved inside `config`** in all 4 places it appears: `measurement_field`, `finished_panel`'s two new fields, `alarm_ack_popup`'s notes field, `nav_shell`'s shift selector.
- **All 10 view `resource.json` files: `scope` changed from `"A"` to `"G"`.** 11 of 11 sampled real views across the reference repos use `"G"`; nothing sampled used `"A"`.
- **`project.json`: `"parent": null` → `"parent": ""`.** Both real reference `project.json` files use empty string, not null.

## Not changed

Everything from v1.2's Critical/High/Medium fix list not mentioned above is unaffected — this pass was specifically about closing the "verified against docs, not against real files" gap the confidence notes flagged, not a re-audit of the whole project. `StagePosition` hardcoding and the alarm pipeline manual-build requirement remain open for the same reasons stated in v1.2.

## Confidence, honestly

This is now verified against **real, working, git-committed Ignition project files**, which is stronger evidence than documentation prose. It is still not verified against a live Designer import — that remains the one check nothing in this environment can substitute for. If you get a chance to actually import this, that result will supersede everything in both changelogs.
