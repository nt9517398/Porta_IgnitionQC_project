# CHANGELOG v1.2 — Independent forensic audit + fix pass

Produced from an independent audit (not the same-context self-review in JUDGE_PASS.md) with GLM-5.2 + DeepSeek cross-checking via `/orchestra`, and every binding/API pattern verified against Inductive Automation's official documentation rather than assumed. Full findings in `IGNITION_FORENSIC_AUDIT_site_quality_control_v1.1.md`.

## Fixed — Critical (all 4; project would not import or function without these)

- **Project structure.** Added root `project.json` and a `resource.json` for each of the 10 views. Confirmed against official docs: every project resource requires one, and every project requires the other. Neither existed in the uploaded export.
- **8 of 9 embedded event scripts had a Python `IndentationError`** (every measurement +/- button, every station's Enter button, the alarm-acknowledge button, and the alarm table's row-click handler). Root cause: a stray leading tab on every line after the first, systematically, across the generator's output. Re-indented all 8; verified with `ast.parse()`, not by eye.
- **`measurement_field`'s value-display binding** used `mode: indirect` with the parameter embedded directly in `path` and no `references` array — the same defect class that caused the prior lathe-form production incident. Restructured to the documented `{1}` + `references` pattern. This one fix covers all 19 usages, since it's a shared component.
- **`finished_panel` had no way to enter a product code or face grade at all** — not just a missing parameter, a missing UI feature. Added two text-field inputs bound to `Pending/ProductCode` / `Pending/FaceGrade`, wired into the submit script's parameter map.

## Fixed — High

- **Alarm row-click** read table data via `self.props.data[event.rowIndex]` (bracket-indexing a Dataset), which official Table Scripting docs and a confirmed forum example both indicate isn't valid. Switched to `event.value`. Also added `event_id` as a rendered column, since `event.value` only carries columns that are actually rendered.
- **Cross-stage correlation query joined the wrong direction** (`t_stamp <= l.t_stamp`, pairing each lathe reading with the *previous* panel's dryer data instead of the one that panel would move to next). Fixed to `>=` with a bounded window. **The 60-minute window is a placeholder** — confirm actual lathe-to-dryer dwell time on this line and adjust.
- **Nav-shell's Alarms-link visibility used `hasRole()`** — per two official Inductive University lessons, the wrong function for Perspective entirely — with the role name and user object swapped even by `hasRole`'s own signature. Replaced with a property binding to `session.props.auth.user.roles` + script transform, matching Ignition's own documented alternative and the plain role-name vocabulary the rest of the project already uses. Not a security fix — `requiredRoles` at the page level was already correctly gating the real access boundary; this only fixed the nav link itself.

## Fixed — Medium

- `shift_code` was `VARCHAR(8)` in all three quality tables. **`'AFTERNOON'` is 9 characters** — every afternoon-shift submission would have failed a column-width check. Found during this fix pass, not in the original audit. Widened to `VARCHAR(16)`, added `CHECK (shift_code IN ('DAY','AFTERNOON','NIGHT'))` against the dropdown's real (verified, not assumed) options.
- Added `CHECK (moisture_min <= moisture_max)` on `dryer_quality`.
- Added a tiebreaker (`record_id`) to the rolling-average `ORDER BY` clauses in both chart queries.
- Session's `activeShift` no longer silently defaults to `"DAY"` — starts blank, so a forgotten shift selection now fails loudly (a real DB error) instead of silently mislabeling every record for the session.

## Deliberately not fixed — with reasons, not silently dropped

- **Alarm pipeline (tag alarm → `alarm_journal` row).** Confirmed via official docs: Alarm Pipelines are Gateway-*global* resources, not part of a project export — this was never going to be deliverable as project JSON, regardless of schema knowledge. A verified build recipe (real block types, real `AlarmEvent` getter methods, not the plausible-but-fabricated ones an initial delegated draft produced) is below. Native Gateway alarming still functions independently; what's missing is only the DB-persisted history/audit trail.
- **`StagePosition` still hardcoded** in the dryer views' submit scripts instead of read from the UDT's own (correctly-configured) parameter. Currently harmless — both values agree — but fixing it would mean reading a UDT *parameter* (not a regular tag) at runtime, and I don't have verified confidence in that access mechanism. Guessing here risks trading a harmless duplicate for an active bug, so it stays as a known, flagged drift risk rather than a blind fix.
- **Missing font files** — cosmetic, degrades gracefully, unchanged from the original disclosure in `DEPLOYMENT.md`.

## Verified alarm pipeline build recipe (Designer, manual — see above for why this can't ship as JSON)

Blocks, in order: **Start → Expression → Script** (not "Path Filter" / "Conditional" — those aren't real Ignition Alarm Pipeline block names; the real palette is Start, Notification, Delay, Splitter, Switch, Expression, Set Property, Jump, Script).

- **Expression block**: condition on the alarm's Display Path or Source starting with `PortaPlywood/QualityControl` — build this in the block editor's expression field using the Alarm Properties picker rather than hand-typing a path, since the exact expression-language function name wasn't independently confirmed here.
- **Script block**:
  ```python
  sourcePath = str(event.getSource())
  displayPath = str(event.getDisplayPath())
  priority = str(event.getPriority())
  state = "Active" if event.isActive() else "Cleared"

  system.db.runNamedQuery("site_quality_control", "qc/alarms/insert_journal_entry", {
      "sourcePath": sourcePath,
      "displayPath": displayPath,
      "priority": priority,
      "state": state
  })
  ```
  Getter-method style (`event.getSource()`, not `event.sourcePath`) confirmed against Inductive Automation's Alarm Event Properties Reference — the Script block's `event` object is documented as sharing its methods with `AlarmEvent`/`PyAlarmEvent`. `runNamedQuery` needs the project name as the first argument in Gateway scope (this matches how the rest of the project already calls it everywhere else).
- Set this pipeline as **both** the Active Pipeline and Clear Pipeline on the relevant alarms (or on the UDT alarm definitions) so both event types flow through and get journaled with the correct `state`.

## Confidence notes carried forward

No live Designer/Gateway was available to round-trip these fixes. Every JSON structural claim, binding pattern, and API signature above was checked against Inductive Automation's official documentation (not assumed, and not taken on a single model's word — GLM and DeepSeek disagreed on several points during this pass, including the alarm pipeline block names, and only the official docs resolved which was right). Confirm on first import regardless.
