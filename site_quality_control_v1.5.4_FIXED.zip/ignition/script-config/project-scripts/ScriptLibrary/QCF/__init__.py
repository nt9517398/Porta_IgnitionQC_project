"""
QCF -- Porta QC Process Control Framework engine.
Aligned to "Ignition QC Process Control System, Complete project framework,
Draft 0.2" (16 July 2026).

Framework 13.4, scripting principles this module exists to satisfy:
  - "Place shared logic in project library scripts, not individual component
     event scripts."
  - "Use parameterised named queries for database access."
  - "Define ONE status evaluation contract used by input components, history
     tables and dashboards."
  - "Use structured logging with inspection ID, station and user context."
  - "Handle database failure explicitly and never show a success state until
     commit confirmation."

This module is the only place a QC status is decided. If a view, a table, or a
dashboard ever computes PASS/WARNING/FAIL itself, that is a defect -- the whole
point of the contract is that an operator's field, the shift log beside it, and
the manager's KPI card can never disagree about the same measurement.
"""

PROJECT = "site_quality_control"
LOGGER_NAME = "QCF"

# Status vocabulary. These exact strings are the contract -- they match the
# CHECK constraints on qc.measurement.result and the Style Class names
# (qcFieldPass / qcFieldWarning / qcFieldFail), so a rename must happen in all
# three places at once, deliberately.
NOT_ENTERED = "NOT_ENTERED"
PASS = "PASS"
WARNING = "WARNING"
FAIL = "FAIL"
NOT_APPLICABLE = "NOT_APPLICABLE"


def _logger():
    return system.util.getLogger(LOGGER_NAME)


def _log_context(inspectionId=None, station=None, user=None):
    """Framework 13.4: structured logging with inspection ID, station and user."""
    return "[insp=%s station=%s user=%s]" % (
        inspectionId if inspectionId is not None else "-",
        station if station else "-",
        user if user else "-",
    )


# =============================================================================
# THE STATUS EVALUATION CONTRACT
# =============================================================================

def evaluate_status(value, appliedMin, appliedMax, appliedTarget=None, warnInset=None):
    """The single status contract. Every component MUST call this.

    Uses the APPLIED limits snapshotted onto the measurement at submission --
    never a live specification lookup. Framework non-negotiable record rule:
    "Store the specification values applied at submission; historical pass/fail
    must not change when a future specification changes." Passing live limits
    into this function for a historical record would silently rewrite history.

    Returns one of: NOT_ENTERED, PASS, WARNING, FAIL.

    A missing limit means unbounded on that side -- a characteristic with only a
    minimum (e.g. bond quality floor) is legitimate and must not be treated as
    a configuration error here.
    """
    if value is None:
        return NOT_ENTERED

    # An unbounded characteristic cannot fail on limits. It is recorded, not judged.
    if appliedMin is None and appliedMax is None:
        return NOT_APPLICABLE

    v = float(value)

    if appliedMin is not None and v < float(appliedMin):
        return FAIL
    if appliedMax is not None and v > float(appliedMax):
        return FAIL

    # Warning band: inset from each limit. NULL warn_inset = no band, so a value
    # inside spec is a straight PASS. Framework 8.1: WARNING is "near limit".
    if warnInset is not None:
        inset = float(warnInset)
        if inset > 0:
            if appliedMin is not None and v < (float(appliedMin) + inset):
                return WARNING
            if appliedMax is not None and v > (float(appliedMax) - inset):
                return WARNING

    return PASS


def deviation(value, appliedTarget):
    """Signed deviation from target, for the framework's normalised comparison
    view ("a value near zero is on target"). None when no target is configured
    -- deviation from nothing is not zero, it is unknown.
    """
    if value is None or appliedTarget is None:
        return None
    return float(value) - float(appliedTarget)


def status_class(status, pulse=False):
    """Maps a status to its Style Class string.

    Returns a SPACE-SEPARATED string, not a list -- confirmed against real
    Ignition project exports, where props.style.classes is always a string and
    multiple classes are space-delimited.

    The pulse flag is deliberately separate from status (framework Appendix A:
    "The pulse flag must be separate from the status"). status=FAIL/pulse=True
    animates three times; status=FAIL/pulse=False stays solid red forever. The
    caller clears pulse after the animation window; status persists until the
    value actually changes.
    """
    if status == FAIL:
        return "qcFieldFail qcPulseFail" if pulse else "qcFieldFail"
    if status == WARNING:
        return "qcFieldWarning qcPulseWarning" if pulse else "qcFieldWarning"
    if status == PASS:
        return "qcFieldPass"
    return "qcFieldNormal"


def badge_class(status):
    """Style Class for a StatusBadge. Framework 4.1: "Use colour plus status
    text, icon and explanation; colour alone is insufficient" -- so this only
    supplies the colour half; the caller must also render status_text().
    """
    return {
        PASS: "qcBadgePass",
        WARNING: "qcBadgeWarning",
        FAIL: "qcBadgeFail",
        NOT_ENTERED: "qcBadgeNeutral",
        NOT_APPLICABLE: "qcBadgeNeutral",
    }.get(status, "qcBadgeNeutral")


def status_text(status):
    """The text half of the colour+text rule. Framework 8.1 status model."""
    return {
        PASS: "PASS",
        WARNING: "WARNING",
        FAIL: "OUT OF SPEC",
        NOT_ENTERED: "NOT ENTERED",
        NOT_APPLICABLE: "RECORDED",
    }.get(status, "UNKNOWN")


def status_message(status, value, appliedMin, appliedMax, unit=None):
    """Human explanation of WHY, with the deviation. Framework 8.2 recommends a
    failed value carries "an OUT OF SPEC label, a deviation message, and a
    visible next-action panel" -- a red border alone is not enough.
    """
    if status == NOT_ENTERED:
        return "No value entered."
    u = (" " + unit) if unit else ""
    v = float(value)
    if status == FAIL:
        if appliedMin is not None and v < float(appliedMin):
            return "%.3f%s is %.3f%s below the minimum of %.3f%s." % (
                v, u, float(appliedMin) - v, u, float(appliedMin), u)
        if appliedMax is not None and v > float(appliedMax):
            return "%.3f%s is %.3f%s above the maximum of %.3f%s." % (
                v, u, v - float(appliedMax), u, float(appliedMax), u)
    if status == WARNING:
        return "%.3f%s is within specification but close to a limit." % (v, u)
    if status == PASS:
        return "%.3f%s is within specification." % (v, u)
    return "%.3f%s recorded (no specification limits configured)." % (v, u)


# =============================================================================
# SPECIFICATION RESOLUTION
# =============================================================================

class SpecificationError(Exception):
    """Raised when specification resolution is ambiguous or finds nothing.

    Framework 11.2: "If zero or multiple equally valid rules are found, block
    submission and raise a configuration exception rather than guessing."
    This exception IS that block. Never catch it and substitute a default --
    a guessed tolerance produces a confident, wrong pass/fail, which is worse
    than a refused submission.
    """
    pass


def resolve_specification(characteristicId, productCode, gradeCode,
                          nominalThickness, variant, stationId, asOf=None):
    """Resolves the one applicable specification, or refuses.

    Returns a dict with min/target/max/warnInset/unit/specificationId.
    Raises SpecificationError on 0 matches or >1 equally-specific matches.
    """
    if asOf is None:
        asOf = system.date.now()

    rows = system.db.runNamedQuery(PROJECT, "qcf/config/resolve_specification", {
        "characteristicId": characteristicId,
        "productCode": productCode,
        "gradeCode": gradeCode,
        "nominalThickness": nominalThickness,
        "variant": variant,
        "stationId": stationId,
        "asOf": asOf,
    })

    count = rows.getRowCount()

    if count == 0:
        raise SpecificationError(
            "No approved specification for characteristic %s (product=%s grade=%s "
            "nominal=%s variant=%s station=%s as of %s). Submission blocked -- a "
            "specification must be configured and approved before this check can "
            "be recorded." % (characteristicId, productCode, gradeCode,
                              nominalThickness, variant, stationId, asOf))

    if count > 1:
        ids = [str(rows.getValueAt(i, "specification_id")) for i in range(count)]
        raise SpecificationError(
            "Ambiguous specification for characteristic %s: %s rules are equally "
            "specific (ids %s). Submission blocked -- QC must retire or narrow one "
            "of them. The system will not guess which limit applies."
            % (characteristicId, count, ", ".join(ids)))

    return {
        "specificationId": rows.getValueAt(0, "specification_id"),
        "min": rows.getValueAt(0, "min_value"),
        "target": rows.getValueAt(0, "target_value"),
        "max": rows.getValueAt(0, "max_value"),
        "warnInset": rows.getValueAt(0, "warn_inset"),
        "unit": rows.getValueAt(0, "unit"),
    }


# =============================================================================
# SUBMISSION
# =============================================================================

def new_idempotency_key():
    """Framework 16.2: "Use an idempotency token so a retry cannot create a
    duplicate inspection." Generate ONCE when the draft opens and keep it for
    the life of that draft -- generating a fresh key per tap defeats the point.

    Ignition's scripting environment is Jython, so java.util.UUID is available
    directly and is the right generator here (no uuid module dependency).
    """
    from java.util import UUID
    return str(UUID.randomUUID())


def submit_inspection(context, measurements, idempotencyKey):
    """Submits one inspection: header + measurements + any non-conformance +
    audit event, in ONE transaction.

    Framework rule: "Save inspection header, measurements, exception creation
    and audit event in one transaction." Partial writes are the failure mode
    this exists to prevent -- a header with no measurements is an inspection
    that claims to have happened but proves nothing.

    Framework rule: "never show a success state until commit confirmation" --
    so this returns (False, message) on any failure and the caller must not
    clear the form or claim success on False.

    context keys: revisionId, lineId, stationId, shiftCode, productCode,
                  gradeCode, nominalThickness, packLoadRef, trackingUnitId,
                  instrumentId, sampleTime, user, comments
    measurements: list of dicts with characteristicId, value, applied* limits,
                  result, deviation
    Returns (success, message, inspectionId).
    """
    log = _logger()
    ctx = _log_context(None, context.get("stationId"), context.get("user"))

    # Refuse to submit a check with nothing in it, before opening a transaction.
    if not measurements:
        return (False, "Nothing to submit: no measurements recorded.", None)

    txId = None
    try:
        txId = system.db.beginNamedQueryTransaction(PROJECT, timeout=10000)

        # insert_header is a Query-type named query using INSERT ... RETURNING,
        # so it returns a one-row dataset, not a scalar.
        headerResult = system.db.runNamedQuery(PROJECT, "qcf/inspection/insert_header", {
            "idempotencyKey": idempotencyKey,
            "revisionId": context["revisionId"],
            "trackingUnitId": context.get("trackingUnitId"),
            "instrumentId": context.get("instrumentId"),
            "lineId": context["lineId"],
            "stationId": context["stationId"],
            "shiftCode": context["shiftCode"],
            "productCode": context.get("productCode"),
            "gradeCode": context.get("gradeCode"),
            "nominalThickness": context.get("nominalThickness"),
            "packLoadRef": context.get("packLoadRef"),
            "sampleTime": context["sampleTime"],
            "submittedBy": context["user"],
            "createdBy": context["user"],
            "comments": context.get("comments"),
            "overallResult": _overall(measurements),
        }, tx=txId)

        if headerResult is None or headerResult.getRowCount() == 0:
            raise Exception("Header insert returned no inspection_id -- aborting rather "
                            "than writing measurements against an unknown inspection.")
        inspectionId = headerResult.getValueAt(0, 0)

        ctx = _log_context(inspectionId, context.get("stationId"), context.get("user"))

        for m in measurements:
            system.db.runNamedQuery(PROJECT, "qcf/inspection/insert_measurement", {
                "inspectionId": inspectionId,
                "characteristicId": m["characteristicId"],
                "specificationId": m.get("specificationId"),
                "valueNumeric": m.get("value"),
                "valueText": m.get("valueText"),
                "appliedMin": m.get("appliedMin"),
                "appliedTarget": m.get("appliedTarget"),
                "appliedMax": m.get("appliedMax"),
                "appliedWarnInset": m.get("appliedWarnInset"),
                "appliedUnit": m.get("appliedUnit"),
                "result": m["result"],
                "deviation": m.get("deviation"),
            }, tx=txId)

        # A failed measurement MUST create the non-conformance in the same
        # transaction. Framework 12: the workflow "cannot be skipped".
        failed = [m for m in measurements if m["result"] == FAIL]
        if failed:
            system.db.runNamedQuery(PROJECT, "qcf/workflow/create_nonconformance", {
                "inspectionId": inspectionId,
                "measurementId": None,
                "trackingUnitId": context.get("trackingUnitId"),
                "severity": "MAJOR",
                "actor": context["user"],
            }, tx=txId)

        system.db.runNamedQuery(PROJECT, "qcf/audit/insert_event", {
            "entityTable": "qc.inspection",
            "entityId": inspectionId,
            "action": "SUBMIT",
            "fieldName": None,
            "oldValue": None,
            "newValue": _overall(measurements),
            "reason": None,
            "actor": context["user"],
            "source": "PERSPECTIVE",
        }, tx=txId)

        system.db.commitNamedQueryTransaction(txId)
        txId = None

        log.info("%s submitted, %s measurements, overall=%s"
                 % (ctx, len(measurements), _overall(measurements)))
        return (True, "Inspection %s submitted." % inspectionId, inspectionId)

    except Exception as e:
        msg = str(e)
        # A unique violation on idempotency_key means this exact submission
        # already committed -- a double-tap or a retry after a timeout. That is
        # a SUCCESS from the operator's point of view, not an error: the record
        # exists and creating a second one would be the actual bug.
        if "idempotency" in msg.lower() or "duplicate key" in msg.lower():
            log.info("%s duplicate submit suppressed (idempotency key already committed)" % ctx)
            return (True, "Already submitted (duplicate tap ignored).", None)
        log.error("%s submit FAILED: %s" % (ctx, msg))
        return (False, "Submit failed, nothing was saved: %s" % msg, None)

    finally:
        if txId is not None:
            try:
                system.db.rollbackNamedQueryTransaction(txId)
                system.db.closeNamedQueryTransaction(txId)
                log.warn("%s transaction rolled back" % ctx)
            except Exception:
                pass


def _overall(measurements):
    """Worst-case roll-up. One FAIL fails the inspection."""
    results = [m["result"] for m in measurements]
    if FAIL in results:
        return FAIL
    if WARNING in results:
        return WARNING
    return PASS
