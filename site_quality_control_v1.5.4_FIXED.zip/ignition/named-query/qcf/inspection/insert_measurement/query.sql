-- applied_* columns are the SNAPSHOT. Framework non-negotiable rule: "Store the
-- specification values applied at submission; historical pass/fail must not
-- change when a future specification changes." Reports read applied_*, never a
-- live join to qc.specification.
INSERT INTO qc.measurement (
    inspection_id, characteristic_id, specification_id,
    value_numeric, value_text,
    applied_min, applied_target, applied_max, applied_warn_inset, applied_unit,
    result, deviation
) VALUES (
    :inspectionId, :characteristicId, :specificationId,
    :valueNumeric, :valueText,
    :appliedMin, :appliedTarget, :appliedMax, :appliedWarnInset, :appliedUnit,
    :result, :deviation
)
