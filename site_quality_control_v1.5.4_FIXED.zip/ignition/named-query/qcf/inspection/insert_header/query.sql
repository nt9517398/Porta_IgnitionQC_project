-- RETURNING gives the database-generated inspection ID (framework rule:
-- "Use database-generated inspection IDs"). idempotency_key is UNIQUE, so a
-- retry raises a duplicate-key error the library catches and treats as success.
-- [SQL SERVER DELTA] RETURNING -> OUTPUT INSERTED.inspection_id
INSERT INTO qc.inspection (
    idempotency_key, revision_id, tracking_unit_id, instrument_id,
    line_id, station_id, shift_code, product_code, grade_code,
    nominal_thickness, pack_load_ref,
    inspection_state, overall_result,
    sample_time, submitted_at, created_by, submitted_by, comments
) VALUES (
    CAST(:idempotencyKey AS UUID), :revisionId, :trackingUnitId, :instrumentId,
    :lineId, :stationId, :shiftCode, :productCode, :gradeCode,
    :nominalThickness, :packLoadRef,
    'SUBMITTED', :overallResult,
    :sampleTime, CURRENT_TIMESTAMP, :createdBy, :submittedBy, :comments
)
RETURNING inspection_id
