-- Framework 5.3: "The current-shift log leads with Status and avoids primary
-- horizontal scrolling." Status first, concise columns only.
SELECT i.inspection_id,
       i.overall_result,
       i.sample_time,
       i.submitted_by,
       i.product_code,
       i.pack_load_ref,
       (SELECT COUNT(*) FROM qc.measurement m
         WHERE m.inspection_id = i.inspection_id AND m.result = 'FAIL') AS failed_count
FROM qc.inspection i
WHERE i.line_id = :lineId
  AND i.station_id = :stationId
  AND i.shift_code = :shiftCode
  AND i.inspection_state IN ('SUBMITTED','AMENDED')
  AND i.sample_time >= :shiftStart
ORDER BY i.sample_time DESC, i.inspection_id DESC
LIMIT :rowLimit
