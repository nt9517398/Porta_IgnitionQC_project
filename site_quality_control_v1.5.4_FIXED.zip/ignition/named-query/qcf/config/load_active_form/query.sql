-- Drives the configuration-driven renderer: one query returns the whole form
-- shape for a station. Adding form #2 is an INSERT into these tables, not a
-- new page and not a schema change.
SELECT fd.form_id, fd.form_code, fd.title AS form_title, fd.process_stage, fd.form_family,
       fr.revision_id, fr.revision_label,
       sd.section_id, sd.section_code, sd.title AS section_title, sd.display_order AS section_order,
       cd.characteristic_id, cd.characteristic_code, cd.label AS characteristic_label,
       cd.data_type, cd.unit, cd.precision_dp, cd.position_code,
       cd.display_order AS characteristic_order, cd.is_required,
       cd.allowed_values, cd.failure_message
FROM qc.form_definition fd
JOIN qc.form_revision fr ON fr.form_id = fd.form_id
JOIN qc.section_definition sd ON sd.revision_id = fr.revision_id
JOIN qc.characteristic_definition cd ON cd.section_id = sd.section_id
WHERE fd.form_code = :formCode
  AND fd.retired_at IS NULL
  AND fr.lifecycle_state = 'ACTIVE'
  AND fr.effective_from <= CURRENT_DATE
  AND (fr.effective_to IS NULL OR fr.effective_to >= CURRENT_DATE)
ORDER BY sd.display_order, cd.display_order
