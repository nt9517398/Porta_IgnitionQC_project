-- Framework 11.2: returns EVERY equally-most-specific ACTIVE match.
-- Deliberately does NOT pick a winner on a tie -- 0 rows or >1 rows are both
-- blocking configuration errors that QCF.resolve_specification() raises on.
SELECT specification_id, min_value, target_value, max_value, warn_inset, unit, specificity
FROM qc.resolve_specification(
    :characteristicId, :productCode, :gradeCode,
    :nominalThickness, :variant, :stationId, CAST(:asOf AS DATE)
)
