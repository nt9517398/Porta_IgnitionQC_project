INSERT INTO qc.audit_event (
    entity_table, entity_id, action, field_name, old_value, new_value,
    reason, actor, source
) VALUES (
    :entityTable, :entityId, :action, :fieldName, :oldValue, :newValue,
    :reason, :actor, :source
)
