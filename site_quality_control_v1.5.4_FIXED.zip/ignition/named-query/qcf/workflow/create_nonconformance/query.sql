-- Created inside the submit transaction so a failure can never be recorded
-- without its workflow. Framework 1.3 success measure: "Out-of-specification
-- results are identified immediately and the required workflow cannot be skipped."
INSERT INTO qc.nonconformance (
    inspection_id, measurement_id, tracking_unit_id, severity, nc_state, opened_at
) VALUES (
    :inspectionId, :measurementId, :trackingUnitId, :severity, 'OPEN', CURRENT_TIMESTAMP
)
