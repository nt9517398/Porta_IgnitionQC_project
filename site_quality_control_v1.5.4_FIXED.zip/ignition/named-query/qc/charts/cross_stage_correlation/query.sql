-- Ported from the old project's cross_stage_correlation query, then corrected
-- in the v1.2 forensic-audit fix pass [H-003]: the original used
-- t_stamp <= l.t_stamp (dryer readings from BEFORE this lathe reading),
-- which pairs each lathe measurement with a previous, unrelated panel's
-- dryer conditions. Physical flow is lathe -> dryer, so a given sheet's
-- dryer reading comes AFTER its lathe reading (confirmed independently by
-- two LLM domain-reasoning passes plus the process-order itself). Fixed to
-- t_stamp >= l.t_stamp, bounded to the nearest upcoming readings.
-- [ASSUMED: 60-minute window -- confirm the real lathe-to-dryer dwell time
-- on this line and adjust the interval below; this default is a placeholder,
-- not a measured value]
SELECT
    l.t_stamp AS lathe_time,
    l.thickness_1 AS lathe_thickness_1,
    (SELECT AVG(sub.thickness_1) FROM (
        SELECT thickness_1 FROM qc.dryer_quality
        WHERE line_id = :lineId AND stage_position = 'INFEED'
          AND t_stamp >= l.t_stamp AND t_stamp < l.t_stamp + INTERVAL '60 minutes'
        ORDER BY t_stamp ASC, record_id ASC LIMIT 3
    ) sub) AS dryer_infeed_avg_thickness_1,
    (SELECT AVG(sub.thickness_1) FROM (
        SELECT thickness_1 FROM qc.dryer_quality
        WHERE line_id = :lineId AND stage_position = 'OUTFEED'
          AND t_stamp >= l.t_stamp AND t_stamp < l.t_stamp + INTERVAL '60 minutes'
        ORDER BY t_stamp ASC, record_id ASC LIMIT 3
    ) sub) AS dryer_outfeed_avg_thickness_1
FROM qc.lathe_quality l
WHERE l.line_id = :lineId AND l.t_stamp >= :startDate AND l.t_stamp < :endDate
ORDER BY l.t_stamp ASC
